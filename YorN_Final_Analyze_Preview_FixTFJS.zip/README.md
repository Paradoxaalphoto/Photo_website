YorN Alpha — Analyze + Preview + Progress (Mobile Fix)
------------------------------------------------------
This build adds TensorFlow.js and switches to TinyFaceDetector on mobile for reliability.

Deploy (GitHub → Vercel):
  1) Upload all files (index.html, vercel.json, README.md) to a GitHub repo.
  2) In Vercel: Import repo → Framework: Other → Build Command: (empty) → Output Directory: .
  3) Deploy.

Notes:
  - Uses CDN weights. No /models folder needed.
  - If you still see errors, open DevTools → Network tab and confirm the weights load (200).
